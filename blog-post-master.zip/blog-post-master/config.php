<?php
// DATABASE SERVER
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'bloghost');